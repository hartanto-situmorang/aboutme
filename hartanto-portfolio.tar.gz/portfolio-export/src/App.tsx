import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { UserMode } from '@/types';
import { ModeSelection } from '@/components/ModeSelection';
import { RecruiterMode, DeveloperMode, HRMode } from '@/components/modes';
import { PlasmaBackground } from '@/components/backgrounds';
import { ArrowLeft } from 'lucide-react';
import './App.css';

function App() {
  const [mode, setMode] = useState<UserMode>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  const handleSelectMode = (selectedMode: UserMode) => {
    setMode(selectedMode);
  };

  const handleBackToSelection = () => {
    setMode(null);
  };

  if (isLoading) {
    return (
      <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <PlasmaBackground />
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative z-10 text-center"
        >
          <motion.div
            animate={{ 
              rotate: 360,
              borderRadius: ['30%', '50%', '30%']
            }}
            transition={{ 
              duration: 2, 
              repeat: Infinity,
              ease: 'linear'
            }}
            className="w-20 h-20 mx-auto mb-6 border-4 border-cyan-400 border-t-transparent rounded-full"
          />
          <motion.h2
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="text-2xl font-bold text-white"
          >
            Loading Portfolio...
          </motion.h2>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="relative">
      <AnimatePresence mode="wait">
        {mode === null ? (
          <motion.div
            key="selection"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <PlasmaBackground />
            <ModeSelection onSelectMode={handleSelectMode} />
          </motion.div>
        ) : (
          <motion.div
            key={mode}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            {/* Back Button */}
            <motion.button
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
              onClick={handleBackToSelection}
              className={`fixed top-6 left-6 z-50 flex items-center gap-2 px-4 py-2 rounded-full backdrop-blur-md transition-all hover:scale-105 ${
                mode === 'developer' 
                  ? 'bg-black/50 text-green-400 border border-green-500/30' 
                  : mode === 'recruiter'
                  ? 'bg-white/10 text-white border border-white/20'
                  : 'bg-white shadow-md text-gray-700'
              }`}
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="text-sm font-medium">Change Mode</span>
            </motion.button>

            {/* Mode Indicator */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className={`fixed top-6 right-6 z-50 px-4 py-2 rounded-full backdrop-blur-md text-sm font-medium ${
                mode === 'developer' 
                  ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
                  : mode === 'recruiter'
                  ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                  : 'bg-blue-100 text-blue-700'
              }`}
            >
              {mode === 'recruiter' && 'Recruiter Mode'}
              {mode === 'developer' && 'Developer Mode'}
              {mode === 'hr' && 'HR Mode'}
            </motion.div>

            {/* Render Selected Mode */}
            {mode === 'recruiter' && <RecruiterMode />}
            {mode === 'developer' && <DeveloperMode />}
            {mode === 'hr' && <HRMode />}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
