import { useEffect, useRef } from 'react';

interface Splash {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  color: string;
  alpha: number;
}

export function SplashCursor() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    const splashes: Splash[] = [];
    const colors = ['#00ff88', '#00ffff', '#ff00ff', '#ffff00', '#ff6600'];

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resize();
    window.addEventListener('resize', resize);

    const createSplash = (x: number, y: number) => {
      const splash: Splash = {
        x,
        y,
        radius: 5,
        maxRadius: 50 + Math.random() * 80,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 1
      };
      splashes.push(splash);
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (Math.random() > 0.7) {
        createSplash(e.clientX, e.clientY);
      }
    };

    const handleClick = (e: MouseEvent) => {
      for (let i = 0; i < 5; i++) {
        setTimeout(() => {
          createSplash(
            e.clientX + (Math.random() - 0.5) * 50,
            e.clientY + (Math.random() - 0.5) * 50
          );
        }, i * 50);
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('click', handleClick);

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (let i = splashes.length - 1; i >= 0; i--) {
        const splash = splashes[i];
        
        ctx.beginPath();
        ctx.arc(splash.x, splash.y, splash.radius, 0, Math.PI * 2);
        ctx.strokeStyle = splash.color;
        ctx.lineWidth = 2;
        ctx.globalAlpha = splash.alpha;
        ctx.stroke();

        // Inner glow
        const gradient = ctx.createRadialGradient(
          splash.x, splash.y, 0,
          splash.x, splash.y, splash.radius
        );
        gradient.addColorStop(0, splash.color + '40');
        gradient.addColorStop(1, 'transparent');
        ctx.fillStyle = gradient;
        ctx.fill();

        splash.radius += 2;
        splash.alpha -= 0.02;

        if (splash.alpha <= 0 || splash.radius >= splash.maxRadius) {
          splashes.splice(i, 1);
        }
      }

      ctx.globalAlpha = 1;
      animationId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('click', handleClick);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none"
      style={{ mixBlendMode: 'screen' }}
    />
  );
}
