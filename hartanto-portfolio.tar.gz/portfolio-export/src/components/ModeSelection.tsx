import { motion } from 'framer-motion';
import { Briefcase, Code, Users } from 'lucide-react';
import type { UserMode } from '@/types';

interface ModeSelectionProps {
  onSelectMode: (mode: UserMode) => void;
}

const modes = [
  {
    id: 'recruiter' as UserMode,
    title: 'Recruiter',
    description: 'View professional projects & achievements',
    icon: Briefcase,
    color: 'from-blue-500 to-cyan-400',
    hoverColor: 'group-hover:from-blue-400 group-hover:to-cyan-300'
  },
  {
    id: 'developer' as UserMode,
    title: 'Developer',
    description: 'Explore deep technical details',
    icon: Code,
    color: 'from-green-500 to-emerald-400',
    hoverColor: 'group-hover:from-green-400 group-hover:to-emerald-300'
  },
  {
    id: 'hr' as UserMode,
    title: 'HR',
    description: 'Discover soft skills & journey',
    icon: Users,
    color: 'from-purple-500 to-pink-400',
    hoverColor: 'group-hover:from-purple-400 group-hover:to-pink-300'
  }
];

export function ModeSelection({ onSelectMode }: ModeSelectionProps) {
  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center p-8">
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
        className="text-center mb-16"
      >
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-4 tracking-tight">
          <span className="bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            Hartanto Situmorang
          </span>
        </h1>
        <p className="text-xl md:text-2xl text-gray-300 font-light">
          Full Stack Developer
        </p>
      </motion.div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.6 }}
        className="text-gray-400 mb-12 text-lg"
      >
        Select your perspective to view my portfolio
      </motion.p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl w-full">
        {modes.map((mode, index) => (
          <motion.button
            key={mode.id}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 + index * 0.15, duration: 0.6 }}
            whileHover={{ scale: 1.05, y: -10 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSelectMode(mode.id)}
            className="group relative"
          >
            <div className={`
              relative overflow-hidden rounded-2xl p-8 
              bg-gradient-to-br ${mode.color} ${mode.hoverColor}
              transition-all duration-500
              shadow-lg hover:shadow-2xl
              border border-white/10 hover:border-white/30
            `}>
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors duration-300" />
              
              <div className="relative z-10 flex flex-col items-center">
                <motion.div
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.6 }}
                  className="mb-6 p-4 rounded-full bg-white/10 backdrop-blur-sm"
                >
                  <mode.icon className="w-12 h-12 text-white" />
                </motion.div>
                
                <h3 className="text-2xl font-bold text-white mb-3">
                  {mode.title}
                </h3>
                
                <p className="text-white/80 text-center text-sm">
                  {mode.description}
                </p>
              </div>

              {/* Animated particles */}
              <div className="absolute inset-0 overflow-hidden pointer-events-none">
                {[...Array(5)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-2 h-2 rounded-full bg-white/30"
                    animate={{
                      x: [0, 100, 0],
                      y: [0, -50, 0],
                      opacity: [0, 1, 0]
                    }}
                    transition={{
                      duration: 3 + i,
                      repeat: Infinity,
                      delay: i * 0.5
                    }}
                    style={{
                      left: `${20 + i * 15}%`,
                      top: `${60 + (i % 2) * 20}%`
                    }}
                  />
                ))}
              </div>
            </div>
          </motion.button>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.6 }}
        className="mt-16 text-gray-500 text-sm"
      >
        <p>Choose the mode that best fits your interest</p>
      </motion.div>
    </div>
  );
}
